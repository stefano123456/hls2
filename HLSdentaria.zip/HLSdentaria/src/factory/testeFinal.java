package factory; 
import java.sql.Connection; 
import java.sql.SQLException; 
public class testeFinal {     
    public static void main(String[] args) throws SQLException {
         Connection connection = new coneccaoFinal().getConnection();
         System.out.println("Conexão aberta!");
         connection.close();
     }
}
