package modelo;
public class cliente {
    String nome, cpf, email, endereco, senha;
    Int telefone;

    public String getNome() {
        return nome;
    }
    public void setNome(String descricao) {
        this.nome = nome;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String detalhes) {
        this.cpf = cpf;
    }
    public String getEmail() { 
        return email;
    } 
    public void setEmail(String imagem) { 
        this.email = email;
    } 
    public String getEndereco() { 
        return endereco;
    } 
    public void setEndereco(String imagem) { 
        this.endereco = endereco;
    } 
    public String getSenha() { 
        return senha;
    } 
    public void setSenha(String imagem) { 
        this.senha = senha;
    } 
        public Int getTelefone() { 
        return telefone;
    } 
    public void setTelefone(Float valor) { 
        this.telefone = telefone;
    } 

        } 


